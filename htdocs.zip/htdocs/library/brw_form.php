<form action="lnd_save.php" method="post" name="brw_form" target="_self">
    <input name="mid" type="hidden" value="<?php echo($mid);?>">
    <center>ยืมหนังสือ (Book ID): <input name="bid" type="text" style="padding: 5px; border: 1px solid #ccc;">
    <input name="submit" type="submit" value="ยืมหนังสือ" style="padding: 5px 10px; background-color: #4CAF50; color: white; border: none; cursor: pointer; border-radius: 5px;"></center>
</form>
