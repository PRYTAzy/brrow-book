<?php
$dbuser="root";
$dbpass="";
$dbhost="localhost";
$dbname="library";
?>